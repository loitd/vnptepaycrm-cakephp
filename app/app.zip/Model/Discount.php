<?php 

App::uses('AppModel', 'Model');

class Discount extends AppModel{
	public $name 	= 'Discount'; // set the model name
	
	public $validate = array(
		

	);

	
	///////////////////
}