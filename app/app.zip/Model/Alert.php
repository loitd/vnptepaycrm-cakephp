<?php 

App::uses('AppModel', 'Model');

class Alert extends AppModel{
	public $name 	= 'Alert'; // set the model name
}