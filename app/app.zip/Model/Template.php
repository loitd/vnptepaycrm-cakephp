<?php 

App::uses('AppModel', 'Model');

class Template extends AppModel{
	public $name 	= 'Template'; // set the model name

	public $validate = array(
		

	);

	
	///////////////////
}